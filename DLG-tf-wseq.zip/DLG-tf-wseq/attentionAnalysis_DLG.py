import sys
import numpy as np

def Recall(train,test,N):
    hit=0
    all=0
    for cont in train:
        if cont not in test:
            #print(cont)
            continue
        Tu=test[cont]
        rank=train[cont][:min(N,len(train[cont]))]
        for item in rank:
            if item in Tu:
                hit+=1
        all+=len(Tu)
    #print(hit)
    #print(all)
    return hit/(all*1.0)

def Precision(train,test,N):
    hit=0
    all=0
    num=0
    for cont in train:
        if cont not in test:
            continue
        num+=1
        Tu=test[cont]
        rank=train[cont][:min(N,len(train[cont]))]
        for item in rank:
            if item in Tu:
                hit+=1
        all+=min(N,len(train[cont]))
    #print(hit)
    #print(all)
    #print(num)
    return hit/(all*1.0)

file1=open(sys.argv[1])
file2=open(sys.argv[2])

Q2A={}
contextFlag=True
cont=""
for line in file1:
    line=line.split()
    if len(line)==0:
        contextFlag=True
        cont=""
        continue
    if contextFlag==True and line[0]!="target:":
        cont+="".join(w for w in line[1:] if w!="<UNK>")+"</d>"
        continue
    if contextFlag==True and line[0]=="target:":
        contextFlag=False
        num=len(line)-1
        Q2A[cont]={}
        for ww in line[1:]:
            Q2A[cont][ww]=[]
        word=""
        continue
    if contextFlag==False and word!="":
        Q2A[cont][word]=[float(w) for w in line]
        word=""
        continue
    if contextFlag==False and word=="":
        word=line[0]
        continue
#print(Q2A)

Q2Anew={}
for cont in Q2A:
    Q2Anew[cont]=[]
    tmp=[]
    for ww in Q2A[cont]:
        if len(tmp)==0:
            tmp=Q2A[cont][ww]
        else:
            for idx in range(len(tmp)):
                tmp[idx]=tmp[idx]+Q2A[cont][ww][idx]
    summ=sum(tmp)
    for idx in range(len(tmp)):
        tmp[idx] = tmp[idx]/summ
    sentences = cont.split("</d>")
    sentences=sentences[:-1]
    #tmp=tmp[:-1]
    tmp2=[]
    for ff in tmp:
        tmp2.append(ff)
    tmp2.sort(reverse=True)
    for ff in tmp2:
        for idx in range(len(tmp)):
            if tmp[idx]==ff:
                break
        offset=max(0,len(sentences)-len(tmp2))
        Q2Anew[cont].append(sentences[idx+offset])
#print(Q2Anew)

humanLabel={}
cont=[]
for line in file2:
    line=line.split()
    if len(line)==0:
        cont=cont[:-1]
        #cont=cont[int(len(cont)/2):]
        if len(cont)>15:
            cont=cont[len(cont)-15:]
        if len(cont)<=1:
            continue
        ctx=""
        for cc in cont:
            ctx+="".join(w for w in cc[1:])+"</d>"
        humanLabel[ctx]=[]
        for cc in cont[:]:
            label=cc[0]
            if label=="1":
                humanLabel[ctx].append("".join(w for w in cc[1:]))
        cont=[]
    else:
        cont.append(line)

pp=Precision(Q2Anew,humanLabel,1)
rr=Recall(Q2Anew,humanLabel,1)
ff=pp*rr/(pp+rr)
print(pp)
print(rr)
print(ff)

pp=Precision(Q2Anew,humanLabel,3)
rr=Recall(Q2Anew,humanLabel,3)
ff=pp*rr/(pp+rr)
print(pp)
print(rr)
print(ff)

pp=Precision(Q2Anew,humanLabel,5)
rr=Recall(Q2Anew,humanLabel,5)
ff=pp*rr/(pp+rr)
print(pp)
print(rr)
print(ff)

pp=Precision(Q2Anew,humanLabel,10)
rr=Recall(Q2Anew,humanLabel,10)
ff=pp*rr/(pp+rr)
print(pp)
print(rr)
print(ff)

pp=Precision(Q2Anew,humanLabel,15)
rr=Recall(Q2Anew,humanLabel,15)
ff=pp*rr/(pp+rr)
print(pp)
print(rr)
print(ff)
'''
print(Precision(Q2Anew,humanLabel,2))
print(Recall(Q2Anew,humanLabel,2))

print(Precision(Q2Anew,humanLabel,3))
print(Recall(Q2Anew,humanLabel,3))

print(Precision(Q2Anew,humanLabel,5))
print(Recall(Q2Anew,humanLabel,5))

print(Precision(Q2Anew,humanLabel,10))
print(Recall(Q2Anew,humanLabel,10))

print(Precision(Q2Anew,humanLabel,15))
print(Recall(Q2Anew,humanLabel,15))

print(Precision(Q2Anew,humanLabel,8))
print(Recall(Q2Anew,humanLabel,8))
'''
